import os
import zipfile

# Define project structure
project_name = "blog_project"
app_name = "blog"

# Directory structure
dirs = [
    f"{project_name}/{app_name}",
    f"{project_name}/{app_name}/migrations",
    f"{project_name}/{app_name}/templates/{app_name}",
    f"{project_name}/{project_name}",
]

# Files and content
files_content = {
    f"{project_name}/manage.py": """\
#!/usr/bin/env python
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'blog_project.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)
""",
    f"{project_name}/{project_name}/__init__.py": "",
    f"{project_name}/{project_name}/settings.py": """\
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-xxxxxxxxxxxxxxxxxxxxxxxxxx'

DEBUG = True

ALLOWED_HOSTS = []

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'blog',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'blog_project.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'blog_project.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True

STATIC_URL = 'static/'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
""",
    f"{project_name}/{project_name}/urls.py": """\
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('blog.urls')),
]
""",
    f"{project_name}/{project_name}/wsgi.py": """\
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'blog_project.settings')
application = get_wsgi_application()
""",
    f"{project_name}/{app_name}/__init__.py": "",
    f"{project_name}/{app_name}/models.py": """\
from django.db import models

class Author(models.Model):
    name = models.CharField(max_length=100)
    bio = models.TextField()

    def __str__(self):
        return self.name

class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.ForeignKey(
        Author,
        on_delete=models.CASCADE,
        related_name='posts'
    )
    published_date = models.DateField()

    def __str__(self):
        return self.title
""",
    f"{project_name}/{app_name}/admin.py": """\
from django.contrib import admin
from .models import Author, Post

admin.site.register(Author)
admin.site.register(Post)
""",
    f"{project_name}/{app_name}/apps.py": f"""\
from django.apps import AppConfig

class BlogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = '{app_name}'
""",
    f"{project_name}/{app_name}/migrations/__init__.py": "",
    f"{project_name}/{app_name}/urls.py": """\
from django.urls import path
from . import views

urlpatterns = [
    path('', views.post_list, name='post_list'),
]
""",
    f"{project_name}/{app_name}/views.py": """\
from django.shortcuts import render
from .models import Post

def post_list(request):
    posts = Post.objects.all()
    return render(request, 'blog/post_list.html', {'posts': posts})
""",
    f"{project_name}/{app_name}/templates/blog/post_list.html": """\
<!DOCTYPE html>
<html>
<head>
    <title>Blog Posts</title>
</head>
<body>
    <h1>Blog Posts</h1>
    <ul>
        {% for post in posts %}
            <li><strong>{{ post.title }}</strong> by {{ post.author.name }} on {{ post.published_date }}</li>
        {% endfor %}
    </ul>
</body>
</html>
""",
}

# Create directories
for directory in dirs:
    os.makedirs(directory, exist_ok=True)

# Write files
for file_path, content in files_content.items():
    with open(file_path, "w") as file:
        file.write(content)

# Zip the project
zip_path = "/mnt/data/blog_project_full.zip"
with zipfile.ZipFile(zip_path, 'w') as blog_zip:
    for root, _, files in os.walk(project_name):
        for file in files:
            full_path = os.path.join(root, file)
            blog_zip.write(full_path, os.path.relpath(full_path, project_name))

zip_path

